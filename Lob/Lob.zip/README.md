This is a very simple command line based implementation of the Lob API in Node.

To Run:

1. Simply run the following commands to install dependency packages:
	`npm install request-promise` and `npm install lob`
2. To run simply type in `node index.js`
3. Enter the prompted information and allow the program to generate the letter